package request;
import java.util.ArrayList;
import response.*;
public class usersRequest{

    /**
     * holds all the register requests.
     */
    public ArrayList<registerRequest> users;

    public usersRequest(ArrayList<registerRequest> newUsers){}

    /**
     * returns the good strings
     * @return
     */
    public String getBody(){return null;}




}